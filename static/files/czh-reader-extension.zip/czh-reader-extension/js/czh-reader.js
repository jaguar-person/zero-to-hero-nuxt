document.getElementById('add-pinyin-btn').addEventListener('click', function (e) {
  // eslint-disable-next-line no-undef
  let Chrome = chrome
  Chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {
    var specTab = tabs[0]
    // Styles
    Chrome.tabs.insertCSS(
      specTab.id,
      { file: 'vendor/jquery/jquery-ui.min.css' }
    )
    Chrome.tabs.insertCSS(
      specTab.id,
      { file: 'css/annotator.css' }
    )
    // Scripts
    Chrome.tabs.executeScript(
      specTab.id,
      { file: 'vendor/pinyinify/pinyinify.js' }
    )
    Chrome.tabs.executeScript(
      specTab.id,
      { file: 'vendor/jquery/jquery.min.js' }
    )
    Chrome.tabs.executeScript(
      specTab.id,
      { file: 'vendor/jquery/jquery-ui.min.js' }
    )
    Chrome.tabs.executeScript(specTab.id,
      { file: 'js/annotator.js' }
    )
  })
})