const Annotator = {
  numCharsInThisRequest: 0,
  nodesToAnnotate: [],
  totalRequests: 0,
  maxNumCharsPerRequest: 100, // 100 characters per batch
  timeout: this.maxNumCharsPerRequest * 5,
  seenNodes: [],
  wordBefore: "",

  walk(node, callback) {
    var done = callback(node);
    node = node.firstChild;
    while (node) {
      this.walk(node, callback);
      node = node.nextSibling;
    }
    return done;
  },

  /**
   * Check if a string contains Chinese characters
   */
  hasChinese(s) {
    var matches = s.match(
      /[\u2E80-\u2E99\u2E9B-\u2EF3\u2F00-\u2FD5\u3005\u3007\u3021-\u3029\u3038-\u303B\u3400-\u4DB5\u4E00-\u9FCC\uF900-\uFA6D\uFA70-\uFAD9]+/g
    );
    return matches;
  },

  collectionContains(collection, item) {
    return collection.indexOf(item) > -1;
  },

  isTextNode(node) {
    return node.nodeType === 3 ? true : false;
  },

  isWordCandidateObjs(wordData) {
    return Array.isArray(wordData);
  },

  spaceBeforeChineseWord(simplified) {
    // Attach these words to the word before
    // If the word before ends in an open quote or open parenthesis, make sure
    // the next word doesn't add a space
    if (wordBefore && wordBefore.match(/[“(]+$/)) {
      return "";
    }
    // If the word ends in an open quote or open parenthesis, add a space before it
    if (wordBefore && wordBefore.match(/[“(]+$/)) {
      return " ";
    }
    if (
      simplified &&
      simplified.match(/^([了着在过住起开呢吗啊呀么吧的]|起来)$/)
    ) {
      return "";
    }
    return " ";
  },

  spaceBeforeNonChineseString(string) {
    var spaceBefore = "";
    // If the word starts with a number or letter, add a space before it
    if (string.match(/^[\d\w]+/)) {
      spaceBefore = " ";
    }
    return spaceBefore;
  },

  findFirstWordWithSimplifiedCharacters(wordObjArray) {
    var i;
    for (i = 0; i < wordObjArray.length; i++) {
      if (wordObjArray[i].simplified) {
        return wordObjArray[i];
      }
    }
    return false;
  },

  getNodeAttributes(wordData) {
    var attributeString = "";
    for (let i = 0; i < wordData.length; i++) {
      if (wordData[i].simplified) {
        attributeString +=
          "data-pinyin-" + i + '="' + wordData[i].pinyin + '" ';
        attributeString +=
          "data-definition-" + i + '="' + wordData[i].definition + '"';
        attributeString +=
          "data-simplified-" + i + '="' + wordData[i].simplified + '"';
      }
    }
    return attributeString;
  },

  annotateNodeWithJSON(dataForNode, node, callback) {
    // Make dataForNode in a nice readable pinyin form
    wordBefore = "";
    let annotatedHTML = "";
    dataForNode.map(wordData => {
      annotatedHTML += this.wordBlockTemplate(wordData);
    });
    let parent = node.parentElement;
    $(node).replaceWith(annotatedHTML);
    callback(parent);
  },

  annotate(nodes, callback) {
    var stringsToSend = [];
    stringsToSend = nodes.map(function(node) {
      return node.nodeValue;
    });
    // eslint-disable-next-line no-undef
    $.post(
      "https://mand.chinesezerotohero.com//api/multitextjsonv2",
      { "text[]": stringsToSend },
      dataForNodes => {
        var i;
        for (i = 0; i < dataForNodes.length; i++) {
          this.annotateNodeWithJSON(dataForNodes[i], nodes[i], callback);
        }
      },
      "json"
    );
  },

  annotateAndClearTaskStatus(callback) {
    var batches = [];
    var thisBatch = [];
    let numCharsSeen = 0;
    var i = 0;
    // Divide nodes into batches
    for (i = 0; i < this.nodesToAnnotate.length; i++) {
      numCharsSeen += this.nodesToAnnotate[i].nodeValue.trim().length;
      thisBatch.push(this.nodesToAnnotate[i]);
      if (numCharsSeen > this.maxNumCharsPerRequest) {
        batches.push(thisBatch);
        thisBatch = [];
        numCharsSeen = 0;
      }
    }
    if (thisBatch.length > 0) {
      batches.push(thisBatch);
    }
    i = 0;
    let next = () => {
      if (i < batches.length) {
        this.annotate(batches[i], callback);
        setTimeout(next, this.timeout);
        i++;
      }
    };
    next(); // recursive
  },

  updateTaskStatus(node) {
    this.seenNodes.push(node);
    this.numCharsInThisRequest =
      this.numCharsInThisRequest + node.nodeValue.length;
    this.totalRequests = this.totalRequests + node.nodeValue.length;
  },

  addAnnotationTask(node) {
    if (this.isTextNode(node)) {
      if (this.hasChinese(node.nodeValue)) {
        // If we have seen this word before, do nothing
        if (this.collectionContains(this.seenNodes, node)) {
          return;
        }
        this.nodesToAnnotate.push(node);
        this.updateTaskStatus(node);
      }
    }
    return true;
  },

  annotateBySelector(selector, callback) {
    // eslint-disable-next-line no-undef
    $(selector)
      .each(function() {
        var children = this.childNodes;
        for (let i = 0; i < children.length; i++) {
          Annotator.addAnnotationTask(children[i]);
        }
      })
      .addClass("add-pinyin show-pinyin show-simplified");
    this.nodesToAnnotate = this.nodesToAnnotate.sort(function(a, b) {
      var arect = a.parentNode.getBoundingClientRect();
      let atop = arect.top;
      var brect = b.parentNode.getBoundingClientRect();
      let btop = brect.top;
      return atop - btop;
    });
    this.annotateAndClearTaskStatus(callback);
    // this.addTooltips();
  },

  wordBlockTemplate(textOrCandidates) {
    if (Array.isArray(textOrCandidates)) {
      let candidates = textOrCandidates;
      let word = candidates[0];
      let book = candidates[0].hsk;
      try {
        return `<span class="word-block" data-candidates="${escape(
          JSON.stringify(candidates)
        )}">
          <span class="word-block-pinyin">${word.pinyin}</span>
          <span class="word-block-simplified">${word.simplified}</span>
          <span class="word-block-traditional">${word.traditional}</span>
          <span class="word-block-definition">${word.definitions[0]}</span>
        </span>`;
      } catch {
        // catch errors
      }
    } else if (typeof textOrCandidates === "string") {
      let text = textOrCandidates;
      return `<span class="word-block"><span class="word-block-text">${text}</span></span>`;
    }
  },

  // old
  addToolTips(node) {
    // eslint-disable-next-line no-undef
    $(node).tooltip({
      items: ".word-block[data-candidates]",
      tooltipClass: "tpd-content",
      hide: { delay: 600 },
      at: "left bottom",
      content: function() {
        // eslint-disable-next-line no-undef
        let s = $(this).attr("data-candidates");
        if (s) {
          var candidates = JSON.parse(unescape(s));
          return Annotator.tooltipTemplate(candidates);
        }
      }
    });
  },

  tooltipTemplate(candidates) {
    let html = "";
    for (let index in candidates) {
      const candidate = candidates[index];
      var $definitionsList = $(`<ol class="tooltip-entry-definitions"></ol>`);
      for (let definition of candidate.definitions) {
        $definitionsList.append(
          `<li class="tooltip-entry-definition">${definition}</li>`
        );
      }
      const traditionalHtml =
        candidate.simplified != candidate.traditional
          ? ` (${candidate.traditional})`
          : "";
      html += `
        <div class="tooltip-entry">
          <a class="tooltip-entry-character" href="http://dictionary.chinesezerotohero.com/#/view/cedict/${
            candidate.traditional
          },${pinyinify(candidate.pinyinCedict).replace(/ /g, "_")},${index}"><span data-hsk="${
        candidate.hsk
      }">${candidate.simplified}</span>${traditionalHtml}</a>
          <span class="tooltip-entry-pinyin">${candidate.pinyin}</span>
          <button onclick="AnnotatorTooltip.speak('${
            candidate.simplified
          }');  return false" class="btn speak"><i class="glyphicon glyphicon-volume-up"></i></button>
          ${$definitionsList.html()}
        </div>`;
    }
    return html;
  }
};

Annotator.annotateBySelector(":visible", node => {
  Annotator.addToolTips(node);
});
